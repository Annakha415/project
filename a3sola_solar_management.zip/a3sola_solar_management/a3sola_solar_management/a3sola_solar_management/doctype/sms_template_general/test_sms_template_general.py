# Copyright (c) 2023, Misma and Contributors
# See license.txt

# import frappe
import unittest

class TestSMSTemplateGeneral(unittest.TestCase):
	pass
