// Copyright (c) 2022, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Roof Type', {
	// refresh: function(frm) {

	// }
});
