// Copyright (c) 2022, Misma and contributors
// For license information, please see license.txt

//frappe.ui.form.on("Assignment Rule", {
    //validate: function(frm) {
        //frappe.model.with_doc("CRM Settings", frm.doc.validate, function() {
            //var tabletransfer= frappe.model.get_doc("CRM Settings", frm.doc.validate)
            //$.each(tabletransfer.lead_users, function(index, row){
                //var d = frm.add_child("Assignment Rule User");
                //d.user = row.lead_users;
				//frm.set_value("users",user)
               // frm.refresh_field("Assignment Rule User");
           // });
      //  });
    //}
	
//});
