# Copyright (c) 2022, Acube Innovations and Contributors
# See license.txt

# import frappe
import unittest

class TestServiceReport(unittest.TestCase):
	pass
