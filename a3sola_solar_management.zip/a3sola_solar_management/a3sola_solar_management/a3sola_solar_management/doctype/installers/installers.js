// Copyright (c) 2023, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Installers', {
	// refresh: function(frm) {

	// }
});
