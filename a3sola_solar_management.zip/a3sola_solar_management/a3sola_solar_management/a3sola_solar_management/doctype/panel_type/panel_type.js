// Copyright (c) 2024, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Panel Type', {
	// refresh: function(frm) {

	// }
});
