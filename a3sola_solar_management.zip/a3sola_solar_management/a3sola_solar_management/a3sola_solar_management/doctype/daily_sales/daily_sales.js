// Copyright (c) 2024, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Daily Sales', {
	// refresh: function(frm) {

	// }
});
