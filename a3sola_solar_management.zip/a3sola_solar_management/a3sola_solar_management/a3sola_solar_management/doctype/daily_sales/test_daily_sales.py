# Copyright (c) 2024, Misma and Contributors
# See license.txt

# import frappe
import unittest

class TestDailySales(unittest.TestCase):
	pass
