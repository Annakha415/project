// Copyright (c) 2022, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Customer Tracking Setting', {
	// refresh: function(frm) {

	// }
});
