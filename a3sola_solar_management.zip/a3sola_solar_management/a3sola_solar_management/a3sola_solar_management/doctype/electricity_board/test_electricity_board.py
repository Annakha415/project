# Copyright (c) 2022, Misma and Contributors
# See license.txt

# import frappe
import unittest

class TestElectricityBoard(unittest.TestCase):
	pass
