// Copyright (c) 2023, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('KSEB Charges', {
	// refresh: function(frm) {

	// }
});
