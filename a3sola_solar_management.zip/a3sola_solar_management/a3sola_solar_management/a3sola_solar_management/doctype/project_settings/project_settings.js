// Copyright (c) 2022, Misma and contributors
// For license information, please see license.txt

frappe.ui.form.on('Project Settings', {
	// refresh: function(frm) {

	// }
});
